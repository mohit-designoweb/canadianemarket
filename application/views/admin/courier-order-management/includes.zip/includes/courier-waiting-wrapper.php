<div class="row">
    <div class="col-md-8 offset-4" id="courier-waiting" data-url="<?php echo base_url('courier/check-for-accept-order/'.$order_id); ?>">
        Please wait while the map is loading. Please don't refresh 
    </div>
</div>