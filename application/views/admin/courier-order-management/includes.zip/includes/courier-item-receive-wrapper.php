<div class="row">
    <div class="col-md-8 offset-4">
        <a href="<?php echo base_url('courier/updateOrderReceivedStatus/' . $courierOrderMappingDetail['courier_order_mapping_id'].'/'.$order_id); ?>" class="btn btn-primary" id="item-recieved">Item Received</a>
    </div>
</div>