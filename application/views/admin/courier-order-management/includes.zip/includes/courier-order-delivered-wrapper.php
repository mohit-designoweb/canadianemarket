<div class="row">
    <div class="col-6 offset-6" >
        <a href="<?php echo base_url('courier/updateCourierDeliveryStatus/' . $courierOrderMappingDetail['courier_order_mapping_id'] . "/" . $order_detail1['order_id']); ?>" id="order-delivered" class="btn btn-primary">Order Delivered</a>
    </div>
</div>